import H_Object from "./H_Object";


function H_Information() {
    return (
        <div className="information">
            
            <ul>
                <li className="flex justify-center p-2">
                    <H_Object></H_Object>
                </li>
                <li className="flex justify-center p-2">
                <H_Object></H_Object>
                </li>
                <li className="flex justify-center p-2">
                <H_Object></H_Object>
                </li>
            </ul>
            <ul>
                <li className="flex justify-center p-2">
                <H_Object></H_Object>
                </li>
                <li className="flex justify-center p-2">
                <H_Object></H_Object>
                </li>
                
            </ul>
            
        </div>
    )
}

export default H_Information;