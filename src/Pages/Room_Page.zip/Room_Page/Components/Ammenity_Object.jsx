function Ammenity_Object(){
    return (
        <div className="flex">
            <img src="https://img.icons8.com/?size=512&id=611&format=png" style={{width:20}}></img>
            {/* TODO 1.7 FILL IN THE AMMENTITIES */}
            <h3>Ammenity Name</h3>
        </div>
    )
}

export default Ammenity_Object