import Ammenity_Object from "./Ammenity_Object";

function Ammenities() {
    return (<>
        
        <div className="ammenities">
            
            <ul>
                <li className="flex justify-center p-2">
                    <Ammenity_Object></Ammenity_Object>
                </li>
                <li className="flex justify-center p-2">
                    <Ammenity_Object></Ammenity_Object>
                </li>
                <li className="flex justify-center p-2">
                    <Ammenity_Object></Ammenity_Object>
                </li>
            </ul>
            <ul>
                <li className="flex justify-center p-2">
                    <Ammenity_Object></Ammenity_Object>
                </li>
                <li className="flex justify-center p-2">
                    <Ammenity_Object></Ammenity_Object>
                </li>
                <li className="flex justify-center p-2">
                    <Ammenity_Object></Ammenity_Object>
                </li>
            </ul>
            <ul>
                <li className="flex justify-center p-2">
                    <Ammenity_Object></Ammenity_Object>
                </li>
                <li className="flex justify-center p-2">
                    <Ammenity_Object></Ammenity_Object>
                </li>
                <li className="flex justify-center p-2">
                    <Ammenity_Object></Ammenity_Object>
                </li>
            </ul>
        </div>
    </>
        
    )
}
export default Ammenities;